#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

// Function to get the current wall time in seconds

int main(int argc, char **argv) {
	int myid, p;

    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &p);
    MPI_Comm_rank(MPI_COMM_WORLD, &myid);
    MPI_Status stat;
    
    int n = pow(2,26);
    int rest = n%p;
    int block_size = rest > myid ? n/p+1 : n/p; // extend block if necessary
    int localsum = 0;
    int* localArray = malloc(sizeof(int)*block_size);
    
    srand(time(NULL)+myid);
    for (int i = 0; i < block_size; i++){
        localArray[i] = rand() % 10;
        localsum += localArray[i];
    }
    free(localArray);
    
    int received, dest;
    int height = (int)ceil(log2(p));

    for (int i = 0; i < height; i++){ // tree summation
        if (myid%((int)pow(2,i+1)) == 0){
            dest = myid + (int)pow(2, i); //receive from right
            if (dest<p){ //only recieve if there is a process to recieve from
                MPI_Recv(&received, 1, MPI_INT, dest, 0, MPI_COMM_WORLD, &stat);
                localsum += received;
            }
        }
        else {
            dest = myid - (int)pow(2, i); //send left
            MPI_Send(&localsum, 1, MPI_INT, dest, 0, MPI_COMM_WORLD);
            break; //if a process sends its value, terminate it
        }
    }
    MPI_Finalize();
    
    if (myid == 0){
        printf("Computed sum = %d\n", localsum);
    }

	return 0;
}
